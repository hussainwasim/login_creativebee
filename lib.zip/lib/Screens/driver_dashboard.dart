import 'package:fin/Components/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});

  @override
  State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        // leading: ClipOval(
        //   child: Image.network(
        //     'https://cdn.dribbble.com/users/1176657/screenshots/15468294/media/34af996ddff444391edab94abcf3c7f3.png?compress=1&resize=300x300',
        //     height: 100.0,
        //     width: 100.0,
        //   ),
        // ),
        title: Text(
          "Hi! Syed Hussain",
          style: TextStyle(
            fontSize: 15,
            color: textPrimary,
          ),
        ),
        elevation: 0,
        actions: [
          IconButton(
              onPressed: (() {}),
              icon: Icon(
                Icons.notifications_active_outlined,
                color: textSecondary,
              ))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 100,
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: primaryColor),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Attendence",
                            style: TextStyle(
                                fontSize: 18,
                                color: primaryWhite,
                                fontWeight: FontWeight.w500),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Text(
                                    "Check In",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: primaryWhite,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  Text(
                                    "10.30 A.M",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: primaryWhite,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                              SizedBox(width: 30),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Text(
                                    "Check Out",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: primaryWhite,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  Text(
                                    "7.30 P.M",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: primaryWhite,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      Container(
                        width: 100,
                        height: 80,
                        child: IconButton(
                            onPressed: (() {}),
                            icon: Icon(
                              Icons.touch_app_outlined,
                              color: textPrimary,
                              size: 45,
                            )),
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: primaryWhite),
                      )
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment(-1, 0),
                    child: Text(
                      "Total Collection Amount",
                      style: TextStyle(
                          color: Color.fromARGB(255, 176, 176, 176),
                          fontSize: 18,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                  Align(
                      alignment: Alignment(-1, 0),
                      child: RichText(
                        text: TextSpan(
                            style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                            ),
                            children: [
                              TextSpan(
                                  text: "12,05,000",
                                  style: TextStyle(color: textPrimary)),
                              TextSpan(
                                  text: ".00/-",
                                  style: TextStyle(color: textSecondary)),
                              TextSpan(
                                  text: "Year",
                                  style: TextStyle(
                                      color: textPrimary, fontSize: 20)),
                            ]),
                      )),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  height: 80,
                  width: 180,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text("Target Collection",
                          style: TextStyle(
                              color: textSecondary,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                      Text("₹ 1200000",
                          style: TextStyle(
                              color: Color.fromARGB(255, 240, 128, 120),
                              fontSize: 18,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                  decoration: BoxDecoration(
                      color: lightGreen,
                      borderRadius: BorderRadius.circular(3)),
                ),
                Container(
                  height: 80,
                  width: 180,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text("Today Collection",
                          style: TextStyle(
                              color: textSecondary,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                      Text("₹ 1200000",
                          style: TextStyle(
                              color: primaryGreen,
                              fontSize: 18,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                  decoration: BoxDecoration(
                      color: lightGreen,
                      borderRadius: BorderRadius.circular(3)),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: 60,
              width: double.infinity,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text("Target Collection",
                      style: TextStyle(
                          color: textSecondary,
                          fontSize: 15,
                          fontWeight: FontWeight.w700)),
                  Container(
                    height: 40,
                    width: 100,
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text("Click here"),
                      icon: Icon(Icons.chevron_right_rounded),
                    ),
                    decoration: BoxDecoration(
                        color: secondaryColor,
                        borderRadius: BorderRadius.circular(3)),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                  color: lightColor, borderRadius: BorderRadius.circular(3)),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  height: 120,
                  width: 100,
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 255, 98, 87),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Danger",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        child: Center(child: Text("5")),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white54,
                          //  borderRadius: BorderRadius.circular(5),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 120,
                  width: 100,
                  decoration: BoxDecoration(
                    color: box03,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Danger",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        child: Center(child: Text("5")),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white54,
                          //  borderRadius: BorderRadius.circular(5),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 120,
                  width: 100,
                  decoration: BoxDecoration(
                    color: box02,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Danger",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        child: Center(child: Text("5")),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white54,
                          //  borderRadius: BorderRadius.circular(5),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:fin/Api_Models/BaseClients.dart';
import 'package:fin/Components/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class CustomerList extends StatefulWidget {
  const CustomerList({super.key});

  @override
  State<CustomerList> createState() => _CustomerListState();
}

class _CustomerListState extends State<CustomerList> {
  bool isLoading = false;
  //Future<CustomerListModel> futureCustomer = getCustomer();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    var futureCustomer = getCustomer();
    setState(() {
      isLoading = true;
    });
  }

  Future<CustomerListModel> getCustomer() async {
    var response = await BaseClient().get('/customer');
    return response;
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Customer List',
          style: TextStyle(
            color: textPrimary,
            fontWeight: FontWeight.w500,
          ),
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: textPrimary,
          ),
          onPressed: () {},
        ),
        elevation: 0,
      ),
      body: ListView.builder(
          itemCount: 1,
          itemBuilder: ((context, index) {
            return Padding(
              padding: const EdgeInsets.only(top: 8.0, left: 10, right: 10),
              child: Container(
                height: 75,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: lightColor,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: secondaryColor,
                      child: Text("hii"),
                    ),
                    title: Text(
                      "Vignesh S / 68541 ",
                      style: TextStyle(
                        color: textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    subtitle: Row(
                      children: [
                        Text(
                          "Finance : ",
                          style: TextStyle(
                            color: textSecondary,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          " 185200 /",
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          " 1420000 ",
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    trailing: Icon(Icons.arrow_forward_ios)),
              ),
            );
          })),
    );
  }
}

class CustomerListModel {
  int? id;
  String? customerName;
  String? customerNumber;

  int? loanAmount;
  int? balanceAmount;

  String? profileUrl;

  CustomerListModel(
      {this.id,
      this.customerName,
      this.customerNumber,
      this.loanAmount,
      this.balanceAmount,
      this.profileUrl});

  CustomerListModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    customerName = json['customer_name'];
    customerNumber = json['customer_number'];
    loanAmount = json["loan_amount"];
    balanceAmount = json["balance_amount"];
    profileUrl = json['profile_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['customer_name'] = this.customerName;
    data['customer_number'] = this.customerNumber;
    data['loan_amount'] = this.loanAmount;
    data['balance_amount'] = this.balanceAmount;
    data['profile_url'] = this.profileUrl;
    return data;
  }
}

import 'package:fin/Api_Models/BaseClients.dart';
import 'package:fin/Api_Models/CustomerModel.dart';
import 'package:fin/Components/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class AddCustomer extends StatefulWidget {
  const AddCustomer({super.key});

  @override
  State<AddCustomer> createState() => _AddCustomerState();
}

class _AddCustomerState extends State<AddCustomer> {
  final _formkey = GlobalKey<FormState>();
  final TextEditingController name = TextEditingController();
  final TextEditingController contactNo = TextEditingController();
  final TextEditingController address = TextEditingController();
  final TextEditingController loanAmount = TextEditingController();

  final TextEditingController dailyDueAmount = TextEditingController();
  final TextEditingController loanDuration = TextEditingController();
  final TextEditingController startingDate = TextEditingController();

//loading
  bool enable = true;

  //save customer fun
  saveCustomer() async {
    setState(() {
      enable = false;
    });
    print(name);
    if (_formkey.currentState!.validate()) {
      await CustomerModel.saveCustomer(
        name,
        contactNo,
        address,
        dailyDueAmount,
        loanAmount,
        loanDuration,
        startingDate,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: (() {}),
          icon: Icon(
            Icons.arrow_back,
            color: textPrimary,
          ),
        ),
        title: Text(
          "Add Customer",
          style: TextStyle(
            fontSize: 15,
            color: textPrimary,
          ),
        ),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              width: 60,
              height: 60,
              child: Center(child: Icon(Icons.cloud_upload_outlined)),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white54,
              ),
            ),
            Text(
              "Profile Picture",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
            ),
            Form(
              key: _formkey,
              child: Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextField(
                        controller: name,
                        decoration: InputDecoration(
                          hintText: "Enter Customer Name ",
                          label: Text("Customer Name"),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                      ),
                      // TextField(
                      //   controller: email,
                      //   keyboardType: TextInputType.url,
                      //   decoration: InputDecoration(
                      //     hintText: "Enter Customer Email ",
                      //     label: Text("Email"),
                      //     border: OutlineInputBorder(),
                      //     focusedBorder: OutlineInputBorder(
                      //       borderSide: BorderSide(
                      //         color: textPrimary,
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      TextField(
                        controller: contactNo,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: "Enter Mobile Number",
                          label: Text("Mobile Number"),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                      ),
                      TextField(
                        controller: address,
                        decoration: InputDecoration(
                          hintText: "Enter Address",
                          label: Text("Address"),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                        maxLines: 3,
                      ),
                      TextField(
                        controller: loanAmount,
                        decoration: InputDecoration(
                          hintText: "Enter Loan Amount ",
                          label: Text("Loan Amount"),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                      TextField(
                        controller: dailyDueAmount,
                        decoration: InputDecoration(
                          hintText: "Enter Daily Loan Amount ",
                          label: Text("Daily Loan Amount"),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                      TextField(
                        controller: loanDuration,
                        decoration: InputDecoration(
                          hintText: "Enter Loan Duration",
                          label: Text('Loan Duration'),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                      TextField(
                        controller: loanDuration,
                        decoration: InputDecoration(
                          hintText: "Enter Loan Starting Date",
                          label: Text('Loan Starting Date'),
                          border: OutlineInputBorder(),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: textPrimary,
                            ),
                          ),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                      ElevatedButton(
                          onPressed: (() {
                            saveCustomer();
                          }),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              minimumSize: Size(double.infinity, 60)),
                          child: Text(
                            'ADD CUSTOMER',
                            style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.bold,
                            ),
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

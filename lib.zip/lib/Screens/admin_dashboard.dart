import 'package:fin/Components/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Hi, Joseph ",
          style: TextStyle(
            fontSize: 16,
            color: textPrimary,
          ),
        ),
        leading: ClipOval(
          child: Image.network(
            'https://cdn.dribbble.com/users/1176657/screenshots/15468294/media/34af996ddff444391edab94abcf3c7f3.png?compress=1&resize=300x300',
            height: 100.0,
            width: 100.0,
          ),
        ),
        elevation: 0,
        toolbarHeight: 70,
        actions: [
          IconButton(
              onPressed: (() {}),
              icon: Icon(
                Icons.notifications_active_outlined,
                color: textSecondary,
              ))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: primaryColor,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Your Total Investment",
                          style: TextStyle(
                            fontSize: 15,
                            color: primaryWhite,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        Text(
                          "12,00,150000.00 /-",
                          style: TextStyle(
                            fontSize: 28,
                            color: primaryWhite,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  child: Container(
                    height: 60,
                    width: 330,
                    decoration: BoxDecoration(
                      color: primaryWhite,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Pending :",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text.rich(
                          TextSpan(children: [
                            WidgetSpan(
                                child: Text(
                              "12,00,150000.00 ",
                              style: TextStyle(
                                fontSize: 20,
                                color: primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                            TextSpan(
                              text: "+ ",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: textPrimary,
                                  fontWeight: FontWeight.bold),
                            ),
                          ]),
                        ),
                        Text.rich(
                          TextSpan(children: [
                            WidgetSpan(
                                child: Text(
                              "Including",
                              style: TextStyle(
                                fontSize: 12,
                                color: textSecondary,
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                            TextSpan(
                              text: "\nInterest",
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold),
                            ),
                          ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  height: 120,
                  width: 120,
                  decoration: BoxDecoration(
                    color: primaryColor,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                  color: Colors.white54,
                                  shape: BoxShape.circle),
                              child: Icon(Icons.next_week_outlined),
                            ),
                            Column(
                              children: [
                                Text(
                                  "Yesterday ",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Collection",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: textSecondary),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Icon(
                          Icons.leaderboard_outlined,
                          color: primaryWhite,
                        ),
                        Container(
                          height: 20,
                          width: double.infinity,
                          child: Center(
                            child: Text(
                              "12,00,000",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: textPrimary),
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 120,
                  width: 120,
                  decoration: BoxDecoration(
                    color: secondaryGreen,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                  color: Colors.white54,
                                  shape: BoxShape.circle),
                              child: Icon(Icons.next_week_outlined),
                            ),
                            Column(
                              children: [
                                Text(
                                  "Today ",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Collection",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: textSecondary),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Icon(
                          Icons.leaderboard_outlined,
                          color: primaryWhite,
                        ),
                        Container(
                          height: 20,
                          width: double.infinity,
                          child: Center(
                            child: Text(
                              "12,00,000",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: textPrimary),
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 120,
                  width: 120,
                  decoration: BoxDecoration(
                    color: primaryColor,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          children: [
                            Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                  color: Colors.white54,
                                  shape: BoxShape.circle),
                              child: Icon(Icons.next_week_outlined),
                            ),
                            Column(
                              children: [
                                Text(
                                  "Tommorow",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Target",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: textSecondary),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Icon(
                          Icons.leaderboard_outlined,
                          color: primaryWhite,
                        ),
                        Container(
                          height: 20,
                          width: double.infinity,
                          child: Center(
                            child: Text(
                              "12,00,000",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: textPrimary),
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment(-1, 0),
                    child: Text(
                      "Total Net Amount",
                      style: TextStyle(
                          color: Color.fromARGB(255, 176, 176, 176),
                          fontSize: 18,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                  Align(
                    alignment: Alignment(-1, 0),
                    child: Row(
                      children: [
                        Text(
                          "12,02,500",
                          style: TextStyle(
                              color: textPrimary,
                              fontSize: 28,
                              fontWeight: FontWeight.w700),
                        ),
                        Text.rich(
                          TextSpan(
                            children: [
                              WidgetSpan(
                                child: Text(
                                  ".00 /- ",
                                  style: TextStyle(
                                      color: Color.fromARGB(255, 176, 176, 176),
                                      fontSize: 28,
                                      fontWeight: FontWeight.w700),
                                ),
                              ),
                              TextSpan(
                                  text: 'Year',
                                  style: TextStyle(
                                      color: textPrimary,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
